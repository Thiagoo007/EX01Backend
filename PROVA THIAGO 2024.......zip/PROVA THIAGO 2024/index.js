const express = require('express')
const app = express()

app.use(express.json())


const FuncioanrioRouter = require('./routes/Funcionario')
app.use(FuncioanrioRouter)

app.listen(3000, () => {
    console.log("Aplicação rodando em http://locahost:3000")
})