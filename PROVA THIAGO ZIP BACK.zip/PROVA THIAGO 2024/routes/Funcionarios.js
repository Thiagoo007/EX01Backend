const express = require('express')
const router = express.Router()

const listaFuncionario = [
    {
        id: 1,
        nome: "Thiago",
        cpf: "0502121515",
        empresa: "DF",
        ano: 2020,
        salario: 4.000
    },
    {
        id: 2,
        nome: "Diego",
        cpf: "0702121413",
        empresa: "Distribuidora e hpc",
        ano: 2024,
        salario: 3.000
    }
]


function validarFuncionario(req, res, next) {
    const id = req.params.id
    const funcionario = listaFuncionario.find(funcionario => funcionario.id == id)
    if (funcionario) {
        req.funcionario = funcionario
        next()
    } else {
        return res.status(404).json({ mensagem: "Funcionario não encontrado!" })
    }
}

function validarAtributos(req, res, next) {
    const dados = req.body
    if (!dados.nome || !dados.cpf || !dados.empresa|| !dados.ano || !dados.salario) {
        return res.status(400).json({ mensagem: "Todos os campos são obrigatórios!" })
    }
    next()
}


router.get('/Funcionario', (req, res) => {
    res.json(listaFuncionario)
})

router.get('/Funcionario/:id', validarFuncionario, (req, res) => {
    res.json(req.funcionario)
})


router.post('/Funcionario', validarAtributos, (req, res) => {
    const dados = req.body

    const Funcionario = {
        id: Math.round(Math.random() * 1000),
        nome: dados.nome,
        cpf: dados.cpf,
        empresa: dados.empresa,
        ano: dados.ano,
        salario: dados.salario
    }

    listaFuncionario.push(Funcionario)

    res.status(201).json(
        {
            mensagem: "Funcionario criado com sucesso!",
            Funcionario
        }
    )
})

router.put('/Funcioanrio/:id', validarAtributos, validarFuncionario, (req, res) => {
    const dados = req.body
    const FuncioanrioAtual = req.Funcionario

    const index = listaFuncionario.findIndex(Funcionario => Funcionario.id == FuncionarioAtual.id)

    const FuncioanrioAtualizado = {
        id: FuncioanrioAtual.id,
        nome: dados.nome,
        cpf: dados.cpf,
        empresa: dados.empresa,
        ano: dados.ano,
        salario: dados.salario
    }

    listaFuncionario[index] = FuncionarioAtualizado

    res.json(
        {
            mensagem: "Funcionario atualizado com sucesso!",
            Funcioanrio: FuncioanrioAtualizado
        }
    )
})
router.delete('/Funcionario/:id', validarFuncionario, (req, res) => {
    const FuncioanrioAtual = req.Funcioanrio
    const index = listaFuncionario.findIndex(funcionario => funcionario.id == FuncioanrioAtual.id)
    listaFuncionario.splice(index, 1)
    res.json({
        mensagem: "Funcionario excluido com sucesso!"
    })
})


router.get('/Funcionario/autor/:autor', (req, res) => {
    const autor = req.params.nome
    const FuncioanrioPorAutor = listaFuncionario.filter(funcionario=> funcionario.autor.toLowerCase() == autor.toLowerCase())
    res.json(FuncioanrioPorAutor)
})


router.get('/Funcionario/preco/media', (req, res) => {

    let soma = 0
    listaFuncionario.forEach(Funcioanrio => {
        soma = soma + Funcioanrio.salario
    })

    const media = soma / listaFuncionario.length

    res.json({
        quantidade: listaFuncionario.length,
        media: media
    })

})








module.exports = router